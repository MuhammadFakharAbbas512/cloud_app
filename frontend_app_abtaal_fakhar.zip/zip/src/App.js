import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    image: null
  });
  const [authData, setAuthData] = useState({
    username: '',
    email: '',
    password: ''
  });
  const [isLogin, setIsLogin] = useState(true);
  const [editingPost, setEditingPost] = useState(null);

  const API_URL = 'http://3.111.245.151:5000'; // Replace with your EC2 IP

  // Set up axios defaults
  axios.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });

  // Check if user is logged in on app load
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      axios.get(`${API_URL}/posts`)
        .then(res => setPosts(res.data))
        .catch(err => console.error(err));
    }
  }, []);

  const handleAuthChange = e => {
    setAuthData({
      ...authData,
      [e.target.name]: e.target.value
    });
  };

  const handleAuthSubmit = async e => {
    e.preventDefault();
    try {
      const endpoint = isLogin ? '/login' : '/register';
      const { data } = await axios.post(`${API_URL}${endpoint}`, authData);
      
      if (isLogin) {
        localStorage.setItem('token', data.token);
        setUser(data.user);
        const postsRes = await axios.get(`${API_URL}/posts`);
        setPosts(postsRes.data);
      } else {
        setIsLogin(true); // Switch to login after registration
        alert('Registration successful! Please login.');
      }
    } catch (err) {
      alert(err.response?.data?.error || 'Something went wrong');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
    setPosts([]);
  };

  const handleInputChange = e => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleFileChange = e => {
    setFormData({
      ...formData,
      image: e.target.files[0]
    });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('title', formData.title);
      formDataToSend.append('content', formData.content);
      if (formData.image) {
        formDataToSend.append('image', formData.image);
      }

      if (editingPost) {
        const { data } = await axios.put(
          `${API_URL}/posts/${editingPost.id}`,
          formDataToSend,
          { headers: { 'Content-Type': 'multipart/form-data' } }
        );
        setPosts(posts.map(post => post.id === data.id ? data : post));
      } else {
        const { data } = await axios.post(
          `${API_URL}/posts`,
          formDataToSend,
          { headers: { 'Content-Type': 'multipart/form-data' } }
        );
        setPosts([...posts, data]);
      }

      setFormData({ title: '', content: '', image: null });
      setEditingPost(null);
    } catch (err) {
      alert(err.response?.data?.error || 'Something went wrong');
    }
  };

  const handleEdit = post => {
    setEditingPost(post);
    setFormData({
      title: post.title,
      content: post.content,
      image: null
    });
  };

  const handleDelete = async id => {
    try {
      await axios.delete(`${API_URL}/posts/${id}`);
      setPosts(posts.filter(post => post.id !== id));
    } catch (err) {
      alert(err.response?.data?.error || 'Something went wrong');
    }
  };

  if (!user) {
    return (
      <div className="auth-container">
        <h2>{isLogin ? 'Login' : 'Register'}</h2>
        <form onSubmit={handleAuthSubmit}>
          {!isLogin && (
            <div>
              <label>Username</label>
              <input
                type="text"
                name="username"
                value={authData.username}
                onChange={handleAuthChange}
                required
              />
            </div>
          )}
          <div>
            <label>Email</label>
            <input
              type="email"
              name="email"
              value={authData.email}
              onChange={handleAuthChange}
              required
            />
          </div>
          <div>
            <label>Password</label>
            <input
              type="password"
              name="password"
              value={authData.password}
              onChange={handleAuthChange}
              required
            />
          </div>
          <button type="submit">{isLogin ? 'Login' : 'Register'}</button>
        </form>
        <button onClick={() => setIsLogin(!isLogin)}>
          {isLogin ? 'Need to register?' : 'Already have an account?'}
        </button>
      </div>
    );
  }

  return (
    <div className="app-container">
      <header>
        <h1>Welcome, {user.username}</h1>
        <button onClick={handleLogout}>Logout</button>
      </header>

      <div className="post-form">
        <h2>{editingPost ? 'Edit Post' : 'Create New Post'}</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label>Title</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              required
            />
          </div>
          <div>
            <label>Content</label>
            <textarea
              name="content"
              value={formData.content}
              onChange={handleInputChange}
              required
            />
          </div>
          <div>
            <label>Image</label>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
            />
          </div>
          <button type="submit">
            {editingPost ? 'Update Post' : 'Create Post'}
          </button>
          {editingPost && (
            <button type="button" onClick={() => setEditingPost(null)}>
              Cancel
            </button>
          )}
        </form>
      </div>

      <div className="posts-list">
        <h2>Your Posts</h2>
        {posts.length === 0 ? (
          <p>No posts yet. Create your first post!</p>
        ) : (
          <ul>
            {posts.map(post => (
              <li key={post.id}>
                <h3>{post.title}</h3>
                <p>{post.content}</p>
                {post.image_url && (
                  <img 
                    src={post.image_url} 
                    alt={post.title} 
                    style={{ maxWidth: '200px' }}
                  />
                )}
                <div className="post-actions">
                  <button onClick={() => handleEdit(post)}>Edit</button>
                  <button onClick={() => handleDelete(post.id)}>Delete</button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default App;